/**
 * 
 * @author codejuzi
 * @CreatedTime 2023年3月28日
 */
public class P4 {
    public static void main(String[] args) {
        char ch = 'A';
        int i = 100;
        System.out.println("输出结果如下：");
        System.out.println("ch = \'" + ch + "\', i = " + i);
    }
}
