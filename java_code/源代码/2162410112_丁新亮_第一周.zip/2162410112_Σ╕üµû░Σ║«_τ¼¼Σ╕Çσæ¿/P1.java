/**
 * 
 * @author codejuzi
 * @CreatedTime 2023年3月28日
 */
public class P1 {
    public static void main(String[] args) {
        System.out.println("姓名：\"小明\"\\学号：\"123456\"");
    }
}
