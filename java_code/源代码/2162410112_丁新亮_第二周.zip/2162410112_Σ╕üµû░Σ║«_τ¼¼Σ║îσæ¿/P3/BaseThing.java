package P3;

/**
 * 事物类接口
 * 
 * @author codejuzi
 * @CreatedTime 2023年4月04日
 */
public interface BaseThing {

    /**
     * 事物行为
     */
    void doSomething(String personName);
}
